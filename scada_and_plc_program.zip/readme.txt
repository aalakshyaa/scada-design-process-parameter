Procedure of restoring SCADA File:

Step 1: Open FactoryTalk view ME application manager
Step 2: Select restore applications 
Step 3: Next
Step 4: Specify the application archive to restore 
Step 5: Finish